import UIKit
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

// наивысший приоритет
let userInteractiveQueue = DispatchQueue.global(qos: .userInteractive)
let userInitiatedQueue = DispatchQueue.global(qos: .userInitiated)
let utilityQueue = DispatchQueue.global(qos: .utility)

// самый низкий приоритет
let backgroundQueue = DispatchQueue.global(qos: .background)

// по умолчанию
let defaultQueue = DispatchQueue.global()

// кастомная serial очередь
let customSerialQueue = DispatchQueue(label: "custom", attributes: .concurrent)

////---------------sync/async------------------
//print("----RACE CONDITION----")
var value = "💁"
var changeValue = { (variant: Int) in
    sleep(1)
    value += "😎"
    print("\(value) - variant \(variant)")
}
//
customSerialQueue.sync {
    changeValue(1)
}
value

sleep(2)

//task completion
func task(_ symbol: String) {
    for i in 1...10 {
        print("\(symbol) \(i) priority = \(qos_class_self().rawValue)")
    }
}

//print("----SERIAL QUEUE SYNC/ASYNC CALL----")
//customSerialQueue.sync {
//    task("👹")
//}
//task("🥶")
//
//customSerialQueue.async {
//    task("👹")
//}
//task("🥶")
//
//sleep(2)

////-------serial async queue------
//print("----SERIAL QUEUES ASYNC CALL----")
//
//let highPriorityCustomQueue = DispatchQueue(label: "highPriorityCustomQueue", qos: .userInitiated)
//highPriorityCustomQueue.async {
//    task("👹")
//}
//
////+ asyncAfter & изменение приоритета
//highPriorityCustomQueue.async() {
//    task("🥶")
//}
//
//sleep(2)
//
////-----concurrent queue-------
//print("----PRIVATE CONCURRENT QUEUE----")
//
//let concurrentQueue = DispatchQueue(label: "concurrentCustomQueue", qos: .userInitiated, attributes: .concurrent)
//concurrentQueue.async {
//    task("👹")
//}
//
////+ asyncAfter & изменение приоритета + initially inactive
//concurrentQueue.async() {
//    task("🥶")
//}
//
//sleep(2)
//
//----dispatch work item-----
//print("----DISPATCH WORK ITEM----")

//let concurrentHighPriorityQueue = DispatchQueue(label: "concurrentHighPriorityQueue", qos: .userInitiated, attributes: .concurrent)
//let concurrentLowPriorityQueue = DispatchQueue(label: "concurrentLowPriorityQueue", qos: .background, attributes: .concurrent)
//
//let highPriorityItem = DispatchWorkItem(qos: .userInitiated, flags: .enforceQoS) {
//    print("🦆")
//}
//
//concurrentHighPriorityQueue.async {
//    task("👹")
//}
//concurrentLowPriorityQueue.async {
//    task("🥶")
//}
//concurrentLowPriorityQueue.async(execute: highPriorityItem)
//concurrentLowPriorityQueue.async(execute: highPriorityItem)
//
//sleep(2)

//------fetching image--------

//let mainView = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
//let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
//imageView.contentMode = .scaleAspectFit
//mainView.addSubview(imageView)
//
//PlaygroundPage.current.liveView = mainView
//
//func fetchImage(for view: UIImageView) {
//
//    let queue = DispatchQueue(label: "imageFetching", qos: .utility)
//
//    queue.async {
//        guard let url = URL(string: "https://pixabay.com/get/52e6d44b4f53af14f6d1867dda3536781539deed53517949_1920.jpg"),
//            let imageData = try? Data(contentsOf: url) else {
//            return
//        }
//
//        DispatchQueue.main.async {
//            imageView.image = UIImage(data: imageData)
//            print("image shown")
//        }
//
//        print("image downloaded")
//    }
//
//}
//fetchImage(for: imageView)
////
////----fetch image with notify
//
//func fetchImageWorkItem() {
//    var data: Data?
//    guard let url = URL(string: "https://pixabay.com/get/52e6d44b4f53af14f6d1867dda3536781539deed53517949_1920.jpg") else {
//        return
//    }
//    let workItem = DispatchWorkItem {
//        data = try? Data(contentsOf: url)
//    }
//    workItem.notify(queue: DispatchQueue.main) {
//        if let imageData = data {
//            imageView.image = UIImage(data: imageData)
//        }
//        print("image shown")
//    }
//
//    let queue = DispatchQueue.global(qos: .utility)
//    queue.async(execute: workItem)
//}
//fetchImageWorkItem()
//
//
//
////------fetching multiple images
//let mainView = UIView(frame: CGRect(x: 0, y: 0, width: 800, height: 800))
//let imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
//let imageView2 = UIImageView(frame: CGRect(x: 400, y: 0, width: 400, height: 400))
//let imageView3 = UIImageView(frame: CGRect(x: 0, y: 400, width: 400, height: 400))
//let imageView4 = UIImageView(frame: CGRect(x: 400, y: 400, width: 400, height: 400))
//let imageViews = [imageView1, imageView2, imageView3, imageView4]
//imageViews.forEach {
//    $0.contentMode = .scaleAspectFit
//    mainView.addSubview($0)
//}
//
//PlaygroundPage.current.liveView = mainView
//
//func fetchImagesWithGroup() {
//    let imageGroup = DispatchGroup()
//    let imageUrls = [
//        "https://pixabay.com/get/53e5d5444d55ad14f6d1867dda3536781539deed5154714b_1920.jpg",
//        "https://pixabay.com/get/52e4d0454256a914f6d1867dda3536781539deed51547548_1920.jpg",
//        "https://pixabay.com/get/52e6d4474a5baa14f6d1867dda3536781539deed5154774f_1920.jpg",
//        "https://pixabay.com/get/53e6d5464c53a914f6d1867dda3536781539deed5157704e_1920.jpg"
//    ]
//
//    var images = [UIImage]()
//
//    for i in 0...1 {
//        DispatchQueue.global().async(group: imageGroup) {
//            guard let url = URL(string: imageUrls[i]),
//                let imageData = try? Data(contentsOf: url),
//                let image = UIImage(data: imageData) else {
//                    return
//            }
//            images.append(image)
////            DispatchQueue.main.async {
////                imageViews[i].image = image
////            }
//        }
//    }
//
//    for i in 2...3 {
//        DispatchQueue.global().async(group: imageGroup) {
//            guard let url = URL(string: imageUrls[i]),
//                let imageData = try? Data(contentsOf: url),
//                let image = UIImage(data: imageData) else {
//                    return
//            }
//            images.append(image)
////            DispatchQueue.main.async {
////                imageViews[i].image = image
////            }
//        }
//    }
//
//    imageGroup.notify(queue: DispatchQueue.main) {
//        for i in 0...3 {
//            imageViews[i].image = images[i]
//        }
//    }
//}
//fetchImagesWithGroup()


////------deadlock--------
//let task = {
//    print("🐤")
//}
//
//let dispQueue = DispatchQueue(label: "com.myqu", qos: .userInitiated)
//
//dispQueue.sync {
//    dispQueue.sync {
//        task()
//    }
//}

//
//--------barrier dispatch----------

//var seals = ["🐬"]
//
//let task = { (item: String) in
//    for _ in 0...10 {
//        seals.append(item)
//    }
//}
//
//let queueUInit = DispatchQueue(label: "com.myqu", qos: .userInitiated, attributes: .concurrent)
//
//queueUInit.async(flags: .barrier) {
//    task("🐊")
//}
//
//queueUInit.async {
//    task("🐋")
//}
//
//sleep(2)
//print(seals)


